#include <iostream>
#include <vector>
#include <iomanip>
#include <cmath>
using namespace std;

class RouteMap
{
private:
    vector<string> stops;
    vector<int> distance; // distance from starting point in km

public:
    RouteMap()
    {
        stops = {"A", "B", "C", "D", "E", "F"};
        distance = {0, 4, 9, 15, 22, 30};
    }

    void displayStops()
    {
        cout << "\nAvailable Bus Stops:\n";
        for (int i = 0; i < stops.size(); i++)
        {
            cout << i + 1 << ". " << stops[i] << "\n";
        }
    }

    int getDistance(int src, int dest)
    {
        return abs(distance[dest] - distance[src]);
    }

    int totalStops()
    {
        return stops.size();
    }
};

class FareCalculator
{
private:
    int ratePerKm;

public:
    FareCalculator()
    {
        ratePerKm = 3; // Rs per km
    }

    int calculateFare(int km)
    {
        return km * ratePerKm;
    }
};

int main()
{
    RouteMap route;
    FareCalculator calc;

    int src, dest;

    cout << "\n--- BUS ROUTE FARE CALCULATOR ---\n";

    while (true)
    {
        route.displayStops();

        cout << "\nEnter Source Stop Number: ";
        cin >> src;
        cout << "Enter Destination Stop Number: ";
        cin >> dest;

        if (src < 1 || src > route.totalStops() || dest < 1 || dest > route.totalStops())
        {
            cout << "\nInvalid stop number! Please try again.\n";
            continue;
        }

        src--;
        dest--; // Convert to index

        int km = route.getDistance(src, dest);
        int fare = calc.calculateFare(km);

        cout << "\nDistance: " << km << " km\n";
        cout << "Fare: Rs. " << fare << "\n";

        char ch;
        cout << "\nCalculate again? (y/n): ";
        cin >> ch;
        if (ch == 'n' || ch == 'N')
            break;
    }

    cout << "\nThank you for using the Bus Route Fare Calculator!\n";
    return 0;
}